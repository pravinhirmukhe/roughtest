<?php
// Manual installation of antivirus website protection

/**
 * Website: http://www.siteguarding.com/
 * Email: support@siteguarding.com
 *
 * @author John Coggins
 * @version 1.0
 * @date 22 Jul 2014
 * @package SiteGuarding Antivirus Installer
 */


 
define('MAIN_SERVER_URL', 'https://www.siteguarding.com/_get_file.php?file=');
define('MAIN_SERVER_IP_1', '185.72.156.128');
define('MAIN_SERVER_IP_2', '185.72.156.129');

error_reporting( 0 );

$script_path = dirname(__FILE__);

$result = array();
$result['status'] = 'ok';


// Checks server settings before installation 

// Check if dir is writable
if (!is_writable($script_path))
{
    $result['status'] = 'error'; 
    $result['errors'][] = 'COM_SAPP_ERROR_DIR_IS_NOT_WRITABLE';
}

// Check ssh
if ( !function_exists('exec') ) 
{
    if (!class_exists('ZipArchive'))
    {
	    $result['status'] = 'error'; 
	    $result['errors'][] = 'Server doesnt support PHP exec function and class ZipArchive is not installed. Please contact your hoster support.';
	}
}
	
	
// Check CURL
if ( !function_exists('curl_init') ) 
{
    $result['status'] = 'error'; 
    $result['errors'][] = 'CURL is not installed on your server. Please contact your hoster support.';
}
       
	    
if ($result['status'] == 'error')
{
	echo json_encode($result);
	exit;
}     
        


// Download and create the files

$access_key = trim($_GET['access_key']);

// Create index.html
CreateFile($script_path, 'index.html', '<html><body bgcolor="#FFFFFF"></body></html>');

// Create php.ini
/*$lines = Read_File($script_path, 'php.ini');
CreateFile($script_path, 'php.ini', $lines.'max_execution_time = 600'."\n".'post_max_size = 256M');*/

// Create antivirus_config.php
$file_content = '<?php'."\n".
	'define("ACCESS_KEY", "'.$access_key.'");'."\n".
    '?>'."\n";
CreateFile($script_path, 'antivirus_config.php', $file_content);

// Create .htaccess
/*$file_content = '# ALLOW ONLY MONITORING SERVER'."\n".
    '<Limit GET POST>'."\n".
    'order deny,allow'."\n".
    'deny from all'."\n".
    'allow from '.MAIN_SERVER_IP_1."\n".
    'allow from '.MAIN_SERVER_IP_2."\n".
    '</Limit>';
CreateFile($script_path, '.htaccess', $file_content);*/

// Create antivirus.php
$file_content = CreateRemote_file_contents(MAIN_SERVER_URL.'antivirus&time='.time(), $script_path.'/antivirus.php');

// Delete this setup.php
unlink(__FILE__);

$result['status'] = 'ok';
$result['errors'][] = ''; 

echo json_encode($result);
exit;




/**
 * Functions
 */

function Read_File($path, $file)
{
    $contents = '';
    
    $filename = $path.'/'.$file;
    if (file_exists($filename))
    {
        $fp = fopen($filename, "r");
        $contents = fread($fp, filesize($filename));
        fclose($fp); 
        
        $contents .= "\n\n";       
    }
    
    return $contents;
}

function CreateFile($path, $file, $content)
{
    $fp = fopen($path.'/'.$file, 'w');
    fwrite($fp, $content);
    fclose($fp);
}

function CreateRemote_file_contents($url, $dst)
{
    if (extension_loaded('curl')) 
    {
        $dst = fopen($dst, 'w');
        
        $ch = curl_init();
        
        curl_setopt($ch, CURLOPT_URL, $url );
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)");
        curl_setopt($ch, CURLOPT_TIMEOUT, 3600);
        curl_setopt($ch, CURLOPT_TIMEOUT_MS, 3600000);
        curl_setopt($ch, CURLOPT_FILE, $dst);
        curl_setopt($ch, CURLOPT_FAILONERROR, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10); // 10 sec
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT_MS, 10000); // 10 sec
        curl_setopt($ch, CURLOPT_BINARYTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        
        $a = curl_exec($ch);
        if ($a === false)  return false;
        
        $info = curl_getinfo($ch);
        
        curl_close($ch);
        fflush($dst);
        fclose($dst);
        
        return $info['size_download'];
    }
    else return false;
        
}
?>