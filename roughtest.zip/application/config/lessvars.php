<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$config['less'] = array(
    'bgColor' => "yellow",
    'bgImg' => "yellow",
    'fontColor' => "#eee",
    'number' => "5",
    'default-size' => "14px",
    'default-color' => "#333333",
    'default-bg-color' => "#ffffff",
    'default-font-color' => "#212121",
    'default-font-color-hover' => "#212121",
    'default-mutedcolor' => "#CCCCCC",
    'default-footer-bg-color' => "#000000"
);
