<style type="text/css">
    p{
        font-weight: normal;
        font-style: normal;
        font-size: 15px;
        color: #999999; 
    }
</style>

<div id="page-wrapper" class="gray-bg dashbard-1">
    <div class="content-main">
        <!--banner-->	
        <?php $this->load->view('admin/layout/breadcrumb');?>
        <?php $jobData = $jobData[0]; ?>
        <!--//banner-->
        <!--content-->
        <div class="content-top">
            <div class="col-md-12">
                <div class="content-top-1 ">
                    <div class="table-responsive">
                        <!--<modal>-->
                        <div class="modal-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Title</label>
                                            <p id="title">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $jobData->title; ?></p>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>location</label>
                                            <p id="location">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $jobData->location; ?></p>
                                        </div>
                                    </div>
                                   <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Graduation Year</label>
                                            <p id="graduation_year">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $jobData->graduation_year; ?></p>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Graduation Branch</label>
                                            <p id="graduation_branch">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo $jobData->graduation_branch; ?></p>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>College CGPA</label>
                                            <p id="college_CGPA">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo $jobData->college_CGPA; ?></p>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>12th Percentage</label>
                                            <p id="twelth_percentage">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo $jobData->twelth_percentage; ?></p>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>10th Percentage</label>
                                            <p id="tenth_percentage">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo $jobData->tenth_percentage; ?></p>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Cost To Company</label>
                                            <p id="cost_to_company">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo $jobData->cost_to_company; ?></p>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Bond</label>
                                            <?php if($jobData->bond == '1'){ ?>
                                                <p id="bond">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Yes</p>
                                            <?php }else{ ?>
                                                 <p id="bond">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; No</p>
                                            <?php } ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                       <div class="form-group">
                                            <label>Expected DOJ</label>
                                            <p id="expected_doj">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo $jobData->expected_doj; ?></p>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Location</label>
                                            <p id="status">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo $jobData->location; ?></p>
                                        </div>
                                    </div>
                                    
                                </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>No Of Recruitment Round</label>
                                        <p id="no_recruitment_round">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo $jobData->no_recruitment_round; ?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Work Description</label>
                                        <p id="work_description">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo $jobData->work_description; ?></p>
                                    </div>
                                </div>
                            </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <center> <a href="<?php print base_url(); ?>admin/Job/job"><button type="button" class="btn btn-primary">Back</button></a></center>
                        </div>
                        
                        <!--</modal>-->

                    </div>  
                </div>
            </div>
            <div class="clearfix"> </div>
        </div>
    </div>
</div>