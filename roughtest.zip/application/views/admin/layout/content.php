<?php

$this->load->view('admin/' . $template);
