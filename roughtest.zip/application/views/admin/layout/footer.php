
<div class="banner">
    <p> &copy; <?= date('Y') ?>. All Rights Reserved </p>
</div>