</td>
<td class='expander'></td>
</tr>
</table>
</td>
</tr>
</table>
<table class='row footer'>
    <tr>
        <td class='wrapper'>
            <table class='six columns'>
                <tr>
                    <td class='left-text-pad'>
                        <h5>Connect With Us:</h5>
                        <table class='tiny-button facebook'>
                            <tr>
                                <td>
                                    <a href='https://www.facebook.com/roughsheet'>Facebook</a>
                                </td>
                            </tr>
                        </table>
                        <br>
                        <table class='tiny-button twitter'>
                            <tr>
                                <td>
                                    <a href='https://twitter.com/roughsheetinc'>Twitter</a>
                                </td>
                            </tr>
                        </table>
                        <br>
                        <table class='tiny-button google-plus'>
                            <tr>
                                <td>
                                    <a href='https://www.linkedin.com/company/roughsheet'>LinkedIn</a>
                                </td>
                            </tr>
                        </table>
                    </td>
                    <td class='expander'></td>
                </tr>
            </table>
        </td>
        <td class='wrapper last'>
            <table class='six columns'>
                <tr>
                    <td class='last right-text-pad'>
                        <h5>We value your suggestions, and hence, please do not hesitate to get in touch with us.</h5>
                        <p>Email: <a href='contact@roughsheet.com'>contact@roughsheet.com</a></p>
                    </td>
                    <td class='expander'></td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<table class='row'>
    <tr>
        <td class='wrapper last'>
            <table class='twelve columns'>
                <tr>
                    <td align='center'>
                <center>
                    <p style='text-align:center;'><a href='<?= SITEURL ?>legal_docs/Terms_Of_Use.html'>Terms</a> | <a href='<?= SITEURL ?>legal_docs/Privacy_Policy.html'>Privacy</a></p>
                </center>
        </td>
        <td class='expander'></td>
    </tr>
</table>
</td>
</tr>
</table>
</td>
</tr>
</table>
</center>
</td>
</tr>
</table>
</body>
</html>