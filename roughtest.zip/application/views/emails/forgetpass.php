<?php $this->load->view('emails/email_head'); ?>
To recover your account, click on the link below.<br>
<br>
<a href='<?= site_url() ?>resetpassword/<?= urlencode($enc) ?>/<?= urlencode($email) ?>'><button>Reset Password</button></a><br>
<br><br>
Regards,
RoughSheet
<?php $this->load->view('emails/email_footer'); ?>