<?php $this->load->view('emails/email_head'); ?>
Greetings!<br>
<br>
Thank you for verifying your email address.<br>
Hope we serve you well.<br>
<br>
Regards,<br>
<br>
Gnana<br>
On behalf of Team RoughSheet
<?php $this->load->view('emails/email_footer'); ?>