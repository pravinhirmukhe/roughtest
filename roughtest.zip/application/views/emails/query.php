Name: <?= $name ?> <br>
Subject: <?= $subject ?> <br>
Email: <?= $email ?> <br>
<br>
Query:<br>
<?= $msg ?>
