<?php

$this->load->view("user/$template");

