<div class="col-sm-12  col-md-12  main hidden-xs" style="background:#fff;border-bottom:2px solid #fc6f4b;" >
    <div class="col-md-12"  style="margin-top:40px;background:#f5f5f5;border-left:2px solid #37a8df;border-right:2px solid #37a8df;padding-bottom:10px;">
        <div class="row placeholders" style="margin-bottom:0px;">
            <div data-intro="This is the Roughsheet Planner!" class="col-xs-6 col-sm-2 placeholder  wow fadeIn" data-wow-delay="0.2s">
                <a href="#/planner" class="list-group-item sm_color5" style="margin-top:20px;">
                    <img  class='glass icon_p'  src="<?= ASSETSURL ?>images/p2.png" >
                      <!--<img src="<?= ASSETSURL ?>images/p2.png" onmouseover="this.src='<?= ASSETSURL ?>images/p5.png';" onmouseout="this.src='<?= ASSETSURL ?>images/p2.png';"></img>-->
                    <h4>Planner</h4>
                               <!--<span
                               style="background: #37a8df;"
                               class="text-muted">Something else</span>-->
                </a>
            </div>
            <div data-intro="This is the Roughsheet Study Material!" class="col-xs-6 col-sm-2 placeholder wow fadeIn" data-wow-delay="0.4s">
                <a  href="#/studymaterial" class="list-group-item sm_color1" style="margin-top:20px;">
                    <img  src="<?= ASSETSURL ?>images/s2.png"  class='glass'>
                    <h4>Study Material</h4>
                                <!--<span class="text-muted">Something else</span>-->
                </a>
                </a>
            </div>
            <div data-intro="This is the Roughsheet Practice Problem Sheets!" class="col-xs-6 col-sm-2 placeholder wow fadeIn" data-wow-delay="0.6s">
                <a  href="#/dpp" class="list-group-item sm_color2" style="margin-top:20px;">
                    <img  class='glass' src="<?= ASSETSURL ?>images/pp2.png">
                    <h4>Practice </br>Problem Sheets</h4>
                                <!--<span class="text-muted">Something else</span>-->
                </a>
            </div>
            <div data-intro="This is the Roughsheet Focus Areas!" class="col-xs-6 col-sm-2 placeholder wow fadeIn" data-wow-delay="0.8s">
                <a href="#/focusarea" class="list-group-item sm_color3" style="margin-top:20px;">
                    <img  class='glass' src="<?= ASSETSURL ?>images/f2.png">
                    <h4>Focus Areas</h4>
                </a>
            </div>
            <div data-intro="This is the Roughsheet My Performance!" class="col-xs-6 col-sm-2 placeholder wow fadeIn" data-wow-delay="1s">
                <a href="#/performance" class="list-group-item sm_color4" style="margin-top:20px;">
                    <img  class='glass' src="<?= ASSETSURL ?>images/m2.png">
                    <h4>My Performance</h4>
                </a>
                <!--
                 <a href="#" onclick="getPage('GALACTICOS')" class="list-group-item" style="margin-top:20px;"><span class="badge">1</span>Galactitos</a>-->
            </div>
            <div data-intro="This is the Roughsheet Ranking!" class="col-xs-6 col-sm-2 placeholder wow fadeIn" data-wow-delay="1s">
                <a href="#/galacticos" class="list-group-item sm_color6 " style="margin-top:20px;">
                    <img  class='glass' src="<?= ASSETSURL ?>images/rank_4.png">
                    <h4>Ranking</h4>
                             <!--<span class="text-muted">Something else</span>-->
                </a>
                <!--
                 <a href="#" onclick="getPage('GALACTICOS')" class="list-group-item" style="margin-top:20px;"><span class="badge">1</span>Galactitos</a>-->
            </div>
        </div> 
    </div>
</div>