<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="RoughSheet is a FREE Interactive and Online Platform to Learn and Practice Aptitude to help crack Company Placement Papers,Daily pratice problem sheet,analysis,Study planner, Focus area,Topic practice problem sheet,Online test,roughsheet, RoughSheet, Aptitude,free test,jobs, recruitment,placements, rough,sheet,rough sheet,www.roughsheet.com,roughsheet.com">
    <meta name="author" content="">
    <link rel="icon" href="<?= ASSETSURL ?>images/tab_icon.png">
    <title><?= SITENAME ?></title>
    <!-- Bootstrap core CSS -->
    <link href="<?= ASSETSURL ?>css/bootstrap.css" rel="stylesheet">
    <link href="<?= ASSETSURL ?>css/datepicker.css" rel="stylesheet">
    <link href="<?= ASSETSURL ?>css/animate.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= ASSETSURL ?>css/crumble.css" >
    <link rel="stylesheet" href="<?= ASSETSURL ?>css/grumble.min.css">
    <link rel="stylesheet" href="<?= ASSETSURL ?>css/style.css">
    <!-- Custom styles for this template -->
    <link href="<?= ASSETSURL ?>css/sticky-footer-navbar.css" rel="stylesheet">
    <!--<link href="<?= ASSETSURL ?>js/prettify.css" rel="stylesheet">-->
    <link href="<?= ANGULARURL ?>node_modules/alertifyjs/build/css/alertify.css" rel="stylesheet">
    <link href="<?= ANGULARURL ?>node_modules/cropper/dist/cropper.css" rel="stylesheet">
    <!--<link rel="stylesheet" href="<?= ANGULARURL ?>node_modules/alertifyjs/build/css/alertify.rtl.css">-->
    <link rel="stylesheet" href="<?= ANGULARURL ?>node_modules/alertifyjs/build/css/themes/default.rtl.css">
    <!--<link rel="stylesheet" href="<?= ANGULARURL ?>introjs/agency.css">-->
    <link rel="stylesheet" href="<?= ANGULARURL ?>introjs/introjs.css">
    <link href="<?= ANGULARURL ?>introjs/themes/introjs-nazanin.css" rel="stylesheet">
    <link href="<?= ANGULARURL ?>fullcalendar.min.css" rel="stylesheet">
    <!--<script src="<?= ASSETSURL ?>js/jquery.js"></script>-->
    <!--<script src="<?= ASSETSURL ?>js/bootstrap.js"></script>-->
    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="<?= ASSETSURL ?>js/ie8-responsive-file-warning.js"></script><![endif]-->
    <!--<script src="<?= ASSETSURL ?>js/ie-emulation-modes-warning.js"></script>-->
    <script src="<?= ANGULARURL ?>node_modules/alertifyjs/build/alertify.js"></script>
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <!--[if lte IE 9]>
    <script src="animation-legacy-support.js"></script>
<![endif]-->
    <script>
        var site_url = "<?= site_url() ?>";
    </script>
    <!--<script src="<?= ASSETSURL ?>js/ajax_func.js"></script>-->
    <link href="http://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet" type="text/css">
    <script src="//connect.facebook.net/en_US/all.js" type="text/javascript"></script>
    <!--<script src="<?= ASSETSURL ?>js/sdk.js" type="text/javascript"></script>-->
    <script>var site_url = "<?= site_url() ?>";</script>
    <script>var appurl = "application/views/user/ang-app";
        var cur_url = "<?= current_url() ?>";
        var FBID = "<?= $this->session->userdata('FBID'); ?>";</script>
    <script src="<?= ANGULARURL ?>angular.min.js" type="text/javascript"></script>
    <script src="<?= ANGULARURL ?>ui-bootstrap.js" type="text/javascript"></script>
    <script src="<?= ANGULARURL ?>angular-route.js"></script>
    <script src="<?= ANGULARURL ?>angular-animate.js"></script>
    <script src="<?= ANGULARURL ?>angular-sanitize.js"></script>
    <link href="<?= ANGULARURL ?>app.css" rel="stylesheet" type="text/css">
    <script src="<?= ANGULARURL ?>angular.control.js" type="text/javascript"></script>
    <script src="<?= ANGULARURL ?>services.js" type="text/javascript"></script>
    <script src="<?= ANGULARURL ?>route.js" type="text/javascript"></script>
    <script>
        (function (i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r;
            i[r] = i[r] || function () {
                (i[r].q = i[r].q || []).push(arguments)
            }, i[r].l = 1 * new Date();
            a = s.createElement(o),
                    m = s.getElementsByTagName(o)[0];
            a.async = 1;
            a.src = g;
            m.parentNode.insertBefore(a, m)
        })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');

        ga('create', 'UA-85599746-1', 'auto');
        ga('send', 'pageview');

    </script>
</head>