<div class="row side_static_menu visible-lg" style="padding: 0px;background:#fff;border-right:solid 2px #febf10;border-left:solid 2px #fc6f4b;border-bottom:solid 2px #febf10;">
    <div class="thumbnail " style="border:0px;margin: 0px;background:#fff;">
        <?php //call_pic(180,180,"img-circle"); ?>
        <img class="media-object" src="<?= IMGURL . $this->session->userdata('UID_Pro_Pic') ?>" style="width:200px;height:214px;border-bottom:solid 3px #37a8df;margin-bottom:1px;" alt="user">
        <p class="media-heading" style="padding:6px;width:170px;color:#fff;background:#fc6f4b;border-top:3px solid #fff;z-index:1000;cursor: pointer;position: absolute;top: 186;border-right:solid 2px #37a8df;border-radius: 0 20px 1px 0px;">
            <?php
            echo $this->session->userdata('UID_Fname') . "&nbsp" . $this->session->userdata('UID_Lname');
            ?>
        </p>
    </div>  
</div>