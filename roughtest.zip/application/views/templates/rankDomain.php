<hr>
<a class="col-md-6 btn btn-default" style='text-decoration: none' onclick="getRankingType(<?php echo $subid; ?>, 'global')">OVERALL</a>
<a  class="col-md-6 btn btn-default"  style='text-decoration: none'onclick="getRankingType(<?php echo $subid; ?>, 'friends')">FRIENDS</a>
<span id="rtype"></span>
<script>
    $(function () {
        $('.col-md-6').click(function () {
            $(this).addClass('active').siblings().removeClass('active');
        });
    });
    $(function () {
        $('.col-md-6').click(function () {
            $(this).addClass('active').siblings().removeClass('active');
        });
    });
</script>