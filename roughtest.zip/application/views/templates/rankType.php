<hr></br>
<center>
    <a class="btn btn-default col-sm-6" style='' onclick="generateRank('<?php echo $subid; ?>', '<?php echo $type; ?>', 'cumulative')" style="margin-right:20px;">CUMULATIVE</a>
    <a class="col-sm-6 btn btn-default" style='' onclick="generateRank('<?php echo $subid; ?>', '<?php echo $type; ?>', 'weekly')">WEEKLY</a>
</center>
</br></br>
<span id="rank"></span>