
<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<ul>
    <?php
//    $val = $_GET['ex_type'];
    if ($val == 1) {
        ?>
        <li>The following exercise contains 20 questions of "easy" difficulty level</li>
        <li>These 20 questions are based on just one chapter, as mentioned in the heading</li>
        <li>The marking scheme for these 20 questions is: +3 for correct answer and -1 for wrong answer</li>
        <li>Questions skipped in the process will not be evaluated</li>
        <li>The maximum marks that can be obtained are +60</li>
        <li>The minimum marks that can be obtained are -20</li>
        <li>Click on "Begin" to start Exercise-1</li>
        <?php
    } else if ($val == 2) {
        ?>
        <li>The following exercise contains 20 questions of "medium" difficulty level</li>
        <li>These 20 questions are based on just one chapter, as mentioned in the heading</li>
        <li>The marking scheme for these 20 questions is: +3 for correct answer and -1 for wrong answer</li>
        <li>Questions skipped in the process will not be evaluated</li>
        <li>The maximum marks that can be obtained are +60</li>
        <li>The minimum marks that can be obtained are -20</li>
        <li>Click on "Begin" to start Exercise-2</li>
        <?php
    } else if ($val == 3) {
        ?>
        <li>The following exercise contains 20 questions of "hard" difficulty level</li>
        <li>These 20 questions are based on just one chapter, as mentioned in the heading</li>
        <li>The marking scheme for these 20 questions is: +3 for correct answer and -1 for wrong answer</li>
        <li>Questions skipped in the process will not be evaluated</li>
        <li>The maximum marks that can be obtained are +60</li>
        <li>The minimum marks that can be obtained are -20</li>
        <li>Click on "Begin" to start Exercise-3</li>
        <?php
    } else if ($val == 'DPP') {
        ?>
        <li>The following Daily Practice Problem Sheet contains 10 questions of varying difficulty level</li>
        <li>These 10 questions are based on just one subject, as mentioned in the heading</li>
        <li>These 10 questions are based on all the chapters that you have already completed of one subject, as mentioned in the heading</li>
        <li>The marking scheme for these 10 questions is: +3 for correct answer and -1 for wrong answer</li>
        <li>Questions skipped in the process will not be evaluated</li>
        <li>The maximum marks that can be obtained are +30</li>
        <li>The minimum marks that can be obtained are -10</li>
        <li>Click on "Begin" to start Daily Practice Problem Sheet</li>
        <?php
    } else if ($val == 'TPP') {
        ?>
        <li>The following Topic Practice Problem Sheet contains 10 questions of varying difficulty level</li>
        <li>These 10 questions are based on just one chapter, as mentioned in the heading</li>
        <li>The marking scheme for these 10 questions is: +3 for correct answer and -1 for wrong answer</li>
        <li>Questions skipped in the process will not be evaluated</li>
        <li>The maximum marks that can be obtained are +30</li>
        <li>The minimum marks that can be obtained are -10</li>
        <li>Click on "Begin" to start Topic Practice Problem Sheet</li>
        <?php
    }
    ?>
</ul>