/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


app.config(function ($routeProvider) {
    $routeProvider
            .when("/", {
                templateUrl: "ang-app/index.html"
            })
            .when("/planner", {
                templateUrl: "ang-app/planner.html"
            })
            .when("/studymaterial", {
                templateUrl: "ang-app/studymaterial.html"
            })
            .when("/friends", {
                templateUrl: "ang-app/friends.html"
            })
            .when("/profile/:fid", {
                templateUrl: "ang-app/profile.html"
            })
            .when("/search/:data", {
                templateUrl: "ang-app/friendsearch.html"
            })
            .when("/keyconcept/:sid/:tid", {
                templateUrl: "ang-app/keycocepts.html",
            })
            .when("/dpp", {
                templateUrl: "ang-app/dpp.html",
            })
            .when("/focusarea", {
                templateUrl: "ang-app/focusarea.html",
            })
            .when("/performance", {
                templateUrl: "ang-app/performance.html",
            })
            .when("/galacticos", {
                templateUrl: "ang-app/galacticos.html",
            })
            .when("/fbfriends", {
                templateUrl: "ang-app/fbfriends.html",
            });
}); 